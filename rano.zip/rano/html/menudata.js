var menudata={children:[
{text:"Page principale",url:"index.html"},
{text:"Structures de données",url:"annotated.html",children:[
{text:"Structures de données",url:"annotated.html"},
{text:"Index des structures de données",url:"classes.html"}]},
{text:"Fichiers",url:"files.html",children:[
{text:"Liste des fichiers",url:"files.html"}]}]}
