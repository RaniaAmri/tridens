var indexSectionsWithContent =
{
  0: "abmpt",
  1: "abmpt",
  2: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers"
};

