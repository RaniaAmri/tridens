var searchData=
[
  ['texte',['texte',['../structtexte.html',1,'']]]
];
